---
name: git-orchestrator
description: Unified skill to handle Git versioning, pull request generation, and release orchestration (merge, tag, and publish).
---

# Git Orchestrator Skill

## When to use this skill
- Before merging your code logic or completing a major feature.
- When creating a Release branch or moving code to Production.

## How to use it
1. **Version Bumping**: Ensure `package.json` gets bumped (e.g., via `npx tsx scripts/bump-version.ts minor`) *before* committing.
2. **Pull Requests (PRs)**: 
   - Analyze local `git diff`.
   - Write a structured PR summary with conventional commits.
   - Execute `gh pr create` with the generated details to open a human-readable PR.
3. **Releases**:
   - Merge approved features into `main`.
   - Tag the git commit: `git tag -a v<version>` and push tags.
   - Instruct the hand-off to `@cloud-deploy` to finalize the release in Production.

## Guardrails
- Version numbers in `.js` or `.tsx` metadata (if any) must perfectly sync with `package.json`.
- Never force push or push a release tag without running automated tests (`@e2e-testing`) first.
