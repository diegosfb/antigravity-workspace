---
name: troubleshooting
description: Use this skill for structured debugging and incident response. It establishes a methodical approach to tracking down errors, exceptions, and unexpected behavior in the codebase.
---

# Troubleshooting Skill

## When to use this skill
- When a bug is reported or an unexpected crash occurs.
- When development is blocked by an unhandled exception or compilation error.
- During incident response in production.

## How to use it
1. **Analyze Context**: Gather all available error logs, stack traces, and steps to reproduce. DO NOT start changing code yet.
2. **Formulate Hypothesis**: Identify the most likely component or file causing the failure.
3. **Isolate**: If possible, write a minimal test or script to consistently reproduce the issue in isolation.
4. **Investigate**: Use `grep_search` or manual inspection to trace where the hypothetical failure point resides. Check recent commits if relevant.
5. **Propose Fix**: Draft the fix and explain *why* it solves the root cause, rather than just treating the symptom.
6. **Verify**: Run the fix against the reproduction steps to guarantee the issue is resolved.
