---
name: performance-optimizer
description: Specialized skill for profiling applications, specifically games or interactive UIs, addressing frame drops, memory leaks, and render bottlenecks.
---

# Performance Optimizer Skill

## When to use this skill
- When the UI feels sluggish, stutters, or drops below 60FPS.
- When memory usage spikes unnecessarily (memory leaks).
- Before optimizing tight loops in core algorithms (like game ticks or physics engines).

## How to use it
1. **Identify Bottlenecks**: Avoid guessing. Request a browser performance profile or look for obvious O(N^2) loops in recurring functions safely.
2. **DOM/Canvas Tuning**:
   - For Canvas: Minimize `ctx.save()` / `ctx.restore()`. Batch rendering calls.
   - For DOM: Avoid layout thrashing. Batch DOM updates. Switch to CSS transforms for animations instead of altering `top/left/width`.
3. **Memory Management**:
   - Limit the creation of unnecessary arrays or objects inside `requestAnimationFrame` loops.
   - Nullify heavy references no longer in use to enable garbage collection.
4. **Execution**: Apply changes, then compare performance visually or via metrics to verify improvement.
