---
name: researcher
description: Consolidated skill to perform multi-source deep investigations, competitive market analysis, and codebase explorations without making impulsive changes.
---

# Researcher Skill

## When to use this skill
- To understand deeply technically complex frameworks or new dependencies.
- To scan the internet for competitor tools or market analysis.
- To act as an investigator before offering coding directions.

## How to use it
1. **Adopt "Read-Only" mindset**: You are exploring, NOT building. Check the `.agent/context.md` "Research Mode".
2. **Tool Iteration**: Use `search_web` and `read_url_content` to pull in domain literature.
3. **Synthesize**: Create detailed breakdown tables, market sizings, or pros/cons comparison charts of open source tools.
4. **Document**: Compile findings tightly into an `artifact` for the user to review, placing hard conclusions *first*.

## Guardrails
- Do NOT output shallow Google results. Keep searching until a deep, comprehensive answer is formed.
