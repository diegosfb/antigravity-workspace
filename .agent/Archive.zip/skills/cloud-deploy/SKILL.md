---
name: cloud-deploy
description: Automates deployments to cloud providers (AWS, GCP, Render). Validates configurations, triggers builds, and manages cloud rollouts.
---

# Cloud Deploy Skill

## When to use this skill
- When you need to push a new version of the app to a target environment (staging/prod).
- After testing, security checks, and version bumping are complete.

## How to use it
1. **Determine Target**: Establish if the user wants `aws`, `gcp`, or `render`.
2. **AWS Deployment (App Runner/ECS)**:
   - Check identity: `aws sts get-caller-identity`
   - Build & push to ECR: `docker build --platform linux/amd64 ...` then push.
   - Run operation: `aws apprunner start-deployment`
3. **GCP Deployment (Cloud Run)**:
   - Check identity: `gcloud auth list`
   - Run operation: `gcloud run deploy battletris-server --source . --region us-central1`
4. **Render Deployment (Blueprint)**:
   - Ensure you push to GitHub first.
   - Render auto-deploys from the connected branch based on `render.yaml`.
   - Provide the user with the dashboard link.

## Guardrails
- Ensure `process.env.PORT` logic matches across targeted container instances.
- Never hardcode cloud secrets; always instruct to fetch them dynamically if needed.
