---
name: technical-writer
description: A specialized documentation skill combining code commenting, Architecture Decision Records (ADRs), and visual architecture overviews (Mermaid diagrams).
---

# Technical Writer Skill

## When to use this skill
- After architectural choices are made (saving ADRs).
- Before submitting a massive feature branch (updating standard Readmes and commenting code).
- When a new cloud service or macro-pattern is introduced (saving architecture diagrams).

## How to use it
1. **ADRs**: Generate timestamped records in `docs/adr/`. Highlight the decision Context, Pros/Cons, and Consequences.
2. **Architecture Visuals**: Update `architecture_readme.md`. Use ````mermaid` syntax to properly draw flowcharts connecting databases, APIs, and the UI.
3. **Code Comments (JSDoc)**: Pass through complex TypeScript/Javascript files and ensure exported types and interfaces have proper doc-strings.
4. **API Payloads**: Update internal specifications to match newly emitted JSON payloads (e.g., matching Socket.io responses).

## Guardrails
- Do NOT alter behavioral TS/JS logic when you are merely meant to be documenting.
