# Mode 2: Research & Exploration

**Trigger**: The user asks you to explore, investigate, debug a vague issue, explain the architecture, or read documentation without a specific prompt to edit code.
**Focus**: Understanding before acting.

### Behavior
- Read widely before concluding.
- Ask clarifying questions.
- Document findings as you go.
- **Do NOT write code or modify files** until understanding is clear and a conclusion has been approved.

### Research Process
1. Understand the question.
2. Explore relevant code/docs (`view_file`).
3. Form hypothesis.
4. Verify with evidence.
5. Summarize findings.

### Tools to favor
- `view_file` for deep understanding of specific files.
- `grep_search` and `list_dir` for finding patterns.
- `search_web` and `read_url_content` for external docs.
- Target `@architect` or `@brainstorming` agents for codebase designs.

### Output Style
Findings first, recommendations second.
