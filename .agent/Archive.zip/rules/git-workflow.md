# Git Workflow

This document defines the project-wide standards for Git operations, commit messaging, and the Pull Request (PR) process.

## Commit Message Format

Commit messages must follow the [Conventional Commits](https://www.conventionalcommits.org/) specification:

`<type>(<scope>): <description>`

### Types
- **feat**: A new feature
- **fix**: A bug fix
- **docs**: Documentation only changes
- **style**: Changes that do not affect the meaning of the code (white-space, formatting, missing semi-colons, etc)
- **refactor**: A code change that neither fixes a bug nor adds a feature
- **perf**: A code change that improves performance
- **test**: Adding missing tests or correcting existing tests
- **chore**: Changes to the build process or auxiliary tools and libraries such as documentation generation

### Rules
- **Description**: Use the imperative, present tense: "change", not "changed" or "changes".
- **Lowercase**: The description must be in lowercase.
- **Atomic**: Commits should be atomic and focused on a single logical change.

## Pull Request Process

1. **Branch Naming**: Use `feature/`, `bugfix/`, `hotfix/`, or `release/` prefixes followed by a descriptive kebab-case name.
2. **PR Description**: Include a clear summary of changes, motivation, and links to any related issues or planning docs.
3. **Draft PR**: Open as a Draft PR if work is incomplete but requires early feedback.
4. **Approval**: PRs must be reviewed by the `@code-reviewer` agent and obtain necessary human approval before merge.
5. **Merge Strategy**: Favor squash merges to keep a clean commit history on the main branch.
