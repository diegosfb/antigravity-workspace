---
description: Build Verification and Patch Release Pipeline
---
This workflow is acts as a Pre-Flight checklist for new builds. It verifies that coding standards, security constraints, logic tests, and health metrics are met before automatically incrementing the patch version (the third number).

// turbo
1. **Coding Standards & Best Practices**: Run `npm run lint` (`tsc --noEmit`) to verify strict TypeScript adherence and syntax quality. Wait for it to pass.
2. **Security Checks**: Run `npm audit` to check for known vulnerabilities in the dependency tree. If anything appears, invoke `@security-reviewer` for analysis.
3. **Run Tests**: Have `@e2e-testing` execute the TestSprite test plan against the local UI. Verify multiplayer logic and Tetris core mechanics are fully green.
// turbo
4. **Health Check & Build Verification**: Run `npm run build` to ensure Vite can successfully compile the frontend React application and bundle it without module resolution errors.
// turbo
5. **Increment Version**: Run `npx tsx scripts/bump-version.ts patch` to safely increment the third number of the application version, reflecting a verified patch build.
6. Run `git add .` followed by `VERSION=$(node -p "require('./package.json').version") && git commit -m "chore: verified patch build v$VERSION"` to securely lock in the new build.
