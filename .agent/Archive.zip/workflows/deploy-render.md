---
description: Deploy application to Render
---
This workflow performs a minor version bump, commits and tags the change locally, pushes to GitHub, and monitors the Render auto-deploy.

// turbo
1. Run `npm run bump:minor` to increment the release version.
// turbo
2. Run `git add package.json src/App.tsx`
// turbo
3. Run `VERSION=$(node -p "require('./package.json').version") && git commit -m "Release v$VERSION"`
// turbo
4. Run `VERSION=$(node -p "require('./package.json').version") && git tag -a v$VERSION -m "Release v$VERSION"`
// turbo
5. Run `git push origin HEAD --tags`
6. Remind the user that Render auto-deploys upon push. Instruct the user to check the dashboard at `https://dashboard.render.com` to verify the Blueprint sync.
