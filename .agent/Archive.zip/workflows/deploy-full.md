---
description: Full deployment to GCP, AWS, and Render
---
This workflow performs a minor version bump, commits and tags the change locally, pushes to GitHub, and deploys atomically to GCP, AWS, and Render mapping across all environments.

// turbo
1. Run `npm run bump:minor` to increment the release version.
// turbo
2. Run `git add package.json src/App.tsx`
// turbo
3. Run `VERSION=$(node -p "require('./package.json').version") && git commit -m "Release v$VERSION"`
// turbo
4. Run `VERSION=$(node -p "require('./package.json').version") && git tag -a v$VERSION -m "Release v$VERSION"`
// turbo
5. Run `git push origin HEAD --tags`
6. **Render**: Automatically triggered by the push in Step 5. Ensure the user monitors the dashboard.
7. **GCP Deploy**: Run `gcloud run deploy battletris-server --source . --region us-central1 --allow-unauthenticated`
// turbo
8. **AWS Build**: Run `docker build --platform linux/amd64 -t battletris-server .`
9. **AWS Deploy**: Inject AWS configs, push the newly built image to ECR, and trigger `aws apprunner start-deployment`.
