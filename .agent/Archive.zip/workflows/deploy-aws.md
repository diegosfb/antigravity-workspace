---
description: Deploy application to AWS App Runner
---
This workflow performs a minor version bump, commits and tags the change locally, pushes to GitHub, builds the Docker image for amd64, and pushes to AWS ECR.

// turbo
1. Run `npm run bump:minor` to increment the release version.
// turbo
2. Run `git add package.json src/App.tsx`
// turbo
3. Run `VERSION=$(node -p "require('./package.json').version") && git commit -m "Release v$VERSION"`
// turbo
4. Run `VERSION=$(node -p "require('./package.json').version") && git tag -a v$VERSION -m "Release v$VERSION"`
// turbo
5. Run `git push origin HEAD --tags`
// turbo
6. Run `docker build --platform linux/amd64 -t battletris-server .`
7. Ensure AWS credentials are set (or inject via `@config-manager`), then login and push the image to your specific ECR URL. 
8. Trigger the App Runner deployment via `aws apprunner start-deployment --service-arn <YOUR_ARN>`.
