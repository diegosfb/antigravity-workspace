## CONCEPTS & HOW TO USE

### Workflows
In Antigravity, **workflows** are explicit sequences of steps executed when they are manually invoked via a slash command (e.g., `/deploy-gcp`).
- **Trigger**: User-invoked or called by another workflow.
- **Nature**: Deterministic, step-by-step trajectory guidance.
- **Location**: `.agent/workflows/`

### Skills
**Skills** are reusable capabilities and specialized guidance packages. Unlike workflows, agents auto-select skills by relevance.
- **Trigger**: Auto-selected based on task description or explicitly mentioned (e.g., `@cloud-deploy`).
- **Nature**: Capability-based assistance and domain-specific guardrails.
- **Location**: `.agent/skills/`

### Agent Manager
The **Agent Manager** is the primary interface and orchestrator for your conversation. It manages the high-level interaction with your codebase and coordinates the available agents to fulfill your requests.
- **Role**: Context management, workspace analysis, and agent delegation.

### Agents
**Agents** are the execution entities that do the actual work.
- **Default Coding Agent**: Even without any custom files in `.agent/agents/`, Antigravity includes a powerful "Default Coding Agent". It is equipped with advanced tools for workspace analysis, terminal execution (@run_command), and code editing (@write_to_file, @replace_file_content).
- **Custom Agents**: These are specialized personas you create (e.g., `@architect`, `@code-reviewer`) in the `.agent/agents/` folder. They extend the system with domain-specific logic and specialized prompt instructions.
- **Trigger**: Agents are "engaged" by default in the conversation or explicitly delegated to for complex phases.

### Rules
**Rules** are persistent, project-wide mandates that shape model behavior and constraints.
- **Trigger**: Always active; they provide reusable prompt-level context.
- **Nature**: Foundational guardrails (e.g., `development.md` defines the Feature Implementation Workflow).
- **Location**: `.agent/rules/`

---

## PROJECT RULEBOOK

These rules define the required behavioral standards for all agent actions:

- **[development.md](./rules/development.md)**: Mandates the "Research & Reuse" first principle and the four-step Feature Implementation Workflow (Plan -> TDD -> Code Review -> Commit).
- **[git-workflow.md](./rules/git-workflow.md)**: Defines Conventional Commits standards and the PR orchestration process.
- **[research.md](./rules/research.md)**: Establishes the "Read-Only" protocol for investigations and exploration.
- **[code-review.md](./rules/code-review.md)**: Sets the severity-based quality gates for auditing code.
- **[testing.md](./rules/testing.md)**: Standardizes the integration of TestSprite and local unit tests.

---

## AGENT & SKILL EXECUTION GUIDE

This outlines the recommended order of execution for common development tasks, mapping our Agents and Skills into logical pipelines.

### 1. Research & Ideation
**Process**: Concept Validation, Market Research, Deep Dives
- 1. **@brainstorming** (Agent): Analyze intent and draft concepts.
- 2. **@researcher** (Skill): Perform deep internet context scanning.
- 3. **@article-writing** (Skill): Synthesize findings into documentation.

### 2. Architecture & Design
**Process**: System Design & Technical Strategy
- 1. **@architect** (Agent): Evaluate trade-offs, scalability, and design patterns.
- 2. **@design-system** (Skill): Establish foundational UI/UX tokens.
- 3. **@technical-writer** (Skill): Generate ADRs and update `architecture_readme.md`.
- 4. **@explain-me** (Skill): Walk through logic and technical approach for human clarity.

### 3. Implementation (Feature/Bug)
**Process**: Following the [Development Rule](./rules/development.md)
- 1. **Plan**: Use `@architect` or `@brainstorming` for the implementation plan.
- 2. **DB Design**: Use `@database-reviewer` (Agent) for schema and RLS policies.
- 3. **Execution**: Use `@agentic-engineering` and `@test-driven-development` (Skills) for the logic.
- 4. **Polish**: Use `@performance-optimizer` (Skill) to profile for bottlenecks.
- 5. **Documentation**: Use `@technical-writer` (Skill) for inline JSDocs and API updates.

### 4. Quality Assurance & Code Review
**Process**: Auditing before merge
- 1. **@security-reviewer** (Agent): Scan for PII, secrets, and CVEs.
- 2. **@database-reviewer** (Agent): Verify SQL efficiency.
- 3. **@code-reviewer** (Agent): Enforce structural style and catch edge cases.
- 4. **@e2e-testing** (Skill): TestSprite end-to-end integration validation.

### 5. Git & Deployment
**Process**: Finalizing and Releasing
- 1. **PR Prep**: Use `@git-orchestrator` (Skill) for versioning and `gh pr create`.
- 2. **Manual Target**: Use `@cloud-deploy` (Skill) to push to AWS, GCP, or Render.
- 3. **Verified Release**: Use `/build-version` followed by `/deploy-full` workflows.

---

## SLASH COMMANDS (WORKFLOWS)

Commands you can trigger explicitly in the chat:

- **/build-version**: Runs the Pre-Flight checklist (lint, audit, build) and bumps the **patch** version.
- **/deploy-gcp**: Minor version bump, tags, and pushes to GCP Cloud Run.
- **/deploy-aws**: Minor version bump, tags, builds docker image, and pushes to AWS App Runner.
- **/deploy-render**: Minor version bump, tags, and pushes to trigger Render auto-deploy.
- **/deploy-full**: One-command atomic release to all three platforms (GCP + AWS + Render).
